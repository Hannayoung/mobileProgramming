package com.cookandroid.myproject;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class food extends Activity {

    SQLiteDatabase sqlDB;
    Button foodInput, foodDelete, foodSaveBtn, calSaveBtn, todayBtn;
    TextView foodTotalCal, year, month, day;
    CalendarView calView;
    LinearLayout otherFunctions;
    ImageButton calendar;
    EditText foodKcal, foodNameResult, foodKcalResult;
    AutoCompleteTextView foodName;
    Calendar curDate = Calendar.getInstance();
    Calendar todayDate = Calendar.getInstance();
    @Override

    public  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food);

        otherFunctions=(LinearLayout)findViewById(R.id.otherFunctions);
        foodInput = (Button)findViewById(R.id.foodInput);
        foodDelete = (Button)findViewById(R.id.foodDelete);
        foodSaveBtn = (Button)findViewById(R.id.foodSaveBtn);
        calSaveBtn = (Button)findViewById(R.id.calSaveBtn);
        todayBtn=(Button)findViewById(R.id.todayBtn);
        calendar=(ImageButton)findViewById(R.id.calendar);
        foodTotalCal = (TextView)findViewById(R.id.foodTotalCal);
        year = (TextView)findViewById(R.id.year);
        month = (TextView)findViewById(R.id.month);
        day = (TextView)findViewById(R.id.day);
        foodNameResult = (EditText)findViewById(R.id.foodNameResult);
        foodKcalResult = (EditText)findViewById(R.id.foodKcalResult);
        foodName = (AutoCompleteTextView)findViewById(R.id.foodName);
        foodKcal = (EditText)findViewById(R.id.foodKcal);
        calView=(CalendarView)findViewById(R.id.calView);
        final foodDBHelper foodHelper = new foodDBHelper(food.this);

        String[] items = {"밥반공기", "밥한공기","참치김치찌개","순두부찌개","부대찌개","해물탕",
                "콩나물국","갈비찜","불고기","감자조림","장조림","낙지볶음","멸치볶음","잡채","김치전","파전",
                "배추김치","깍두기","설렁탕","삼계탕","떡국","칼국수","물냉면","비빔냉면","비빔밥","만두국",
                "라면","떡볶이","메론(100g)","귤","딸기","바나나","배","복숭아","사과", "수박","자두","참외","키위",
                "파인애플","포도","토마토","오렌지","아몬드","아이비","칙촉","초코파이","새우깡","홈런볼","에이스",
                "초콜릿","치킨 3조각","너겟 5조각","감자튀김","콘샐러드","케잌1조각","도넛1조각","베이글1개","카스테라",
                "피자1조각","샌드위치","볶음밥","짜장면","우동","짬뽕","탕수육","유부초밥","김밥1줄","콜라","사이다","주스",
                "아메리카노","카페라떼","카페모카","카푸치노","우유","소주1병","맥주500ml","막걸리1병",};

        AutoCompleteTextView auto = (AutoCompleteTextView)findViewById(R.id.foodName);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,items);
        auto.setAdapter(adapter);

        String today = Integer.toString(curDate.get(Calendar.YEAR))+Integer.toString(1+curDate.get(Calendar.MONTH))+Integer.toString(curDate.get(Calendar.DATE));
        year.setText(Integer.toString(curDate.get(Calendar.YEAR)));
        month.setText(Integer.toString(1+curDate.get(Calendar.MONTH)));
        day.setText(Integer.toString(curDate.get(Calendar.DATE)));

        sqlDB = foodHelper.getReadableDatabase();
        Cursor cursor;
        cursor = sqlDB.rawQuery("SELECT fName, fKcal FROM foodTBL WHERE Date =\""+today+"\";", null);
        String strNames = "음식 이름" + "\r\n"+"-------"+"\r\n";
        String strKcal = "칼 로 리" + "\r\n"+"-------"+"\r\n";
        int totalCal = 0;
        while(cursor.moveToNext()){
            strNames += cursor.getString(0)+"\r\n";
            strKcal += Integer.toString(cursor.getInt(1))+"\r\n";
            totalCal = totalCal+cursor.getInt(1);
        }
        foodNameResult.setText(strNames);
        foodKcalResult.setText(strKcal);
        foodTotalCal.setText(Integer.toString(totalCal));
        cursor.close();
        sqlDB.close();

        calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calView.setVisibility(View.VISIBLE);
                calSaveBtn.setVisibility(View.VISIBLE);
                otherFunctions.setVisibility(View.INVISIBLE);
            }
        });

        calSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                curDate.setTimeInMillis(calView.getDate());
                year.setText(Integer.toString(curDate.get(Calendar.YEAR)));
                month.setText(Integer.toString(1+curDate.get(Calendar.MONTH)));
                day.setText(Integer.toString(curDate.get(Calendar.DATE)));
                calView.setVisibility(View.INVISIBLE);
                calSaveBtn.setVisibility(View.INVISIBLE);
                otherFunctions.setVisibility(View.VISIBLE);

                String date = Integer.toString(curDate.get(Calendar.YEAR))+Integer.toString(1+curDate.get(Calendar.MONTH))+Integer.toString(curDate.get(Calendar.DATE));
                sqlDB = foodHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT fName, fKcal FROM foodTBL WHERE Date=\""+date+"\";", null);
                String strNames = "음식 이름" + "\r\n"+"-------"+"\r\n";
                String strKcal = "칼 로 리" + "\r\n"+"-------"+"\r\n";
                int totalCal = 0;
                while(cursor.moveToNext()){
                    strNames += cursor.getString(0)+"\r\n";
                    strKcal += Integer.toString(cursor.getInt(1))+"\r\n";
                    totalCal = totalCal+cursor.getInt(1);
                }
                foodNameResult.setText(strNames);
                foodKcalResult.setText(strKcal);
                foodTotalCal.setText(Integer.toString(totalCal));
                cursor.close();
                sqlDB.close();

            }
        });

        todayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                year.setText(Integer.toString(todayDate.get(Calendar.YEAR)));
                month.setText(Integer.toString(1+todayDate.get(Calendar.MONTH)));
                day.setText(Integer.toString(todayDate.get(Calendar.DATE)));
                String returnToday = year.getText().toString()+month.getText().toString()+day.getText().toString();

                sqlDB = foodHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT fName, fKcal FROM foodTBL WHERE Date =\""+returnToday+"\";", null);
                String strNames = "음식 이름" + "\r\n"+"-------"+"\r\n";
                String strKcal = "칼 로 리" + "\r\n"+"-------"+"\r\n";
                int totalCal = 0;
                while(cursor.moveToNext()){
                    strNames += cursor.getString(0)+"\r\n";
                    strKcal += Integer.toString(cursor.getInt(1))+"\r\n";
                    totalCal = totalCal+cursor.getInt(1);
                }
                foodNameResult.setText(strNames);
                foodKcalResult.setText(strKcal);
                foodTotalCal.setText(Integer.toString(totalCal));
                cursor.close();
                sqlDB.close();
            }
        });
        foodInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=foodName.getText().toString();
                String kcl=foodKcal.getText().toString();
                String calDate = year.getText().toString()+month.getText().toString()+day.getText().toString();

                int nameSize = name.length();
                int kclSize = kcl.length();
                if(nameSize <= 0 || kclSize <= 0){
                    Toast.makeText(getApplicationContext(),"음식명 혹은 칼로리를 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    sqlDB = foodHelper.getWritableDatabase();
                    sqlDB.execSQL("INSERT INTO foodTBL VALUES(\"" + calDate + "\",\"" + name + "\"," + Integer.parseInt(kcl) + ");");
                    sqlDB.close();
                    sqlDB = foodHelper.getReadableDatabase();
                    Cursor cursor;
                    cursor = sqlDB.rawQuery("SELECT fName, fKcal FROM foodTBL WHERE Date=\"" + calDate + "\"", null);
                    String strNames = "음식 이름" + "\r\n" + "-------" + "\r\n";
                    String strKcal = "칼 로 리" + "\r\n" + "-------" + "\r\n";
                    int totalCal = 0;
                    while (cursor.moveToNext()) {
                        strNames += cursor.getString(0) + "\r\n";
                        strKcal += Integer.toString(cursor.getInt(1)) + "\r\n";
                        totalCal = totalCal + cursor.getInt(1);
                    }
                    foodNameResult.setText(strNames);
                    foodKcalResult.setText(strKcal);
                    foodTotalCal.setText(Integer.toString(totalCal));
                    cursor.close();
                    sqlDB.close();
                    foodName.setText("");
                    foodKcal.setText("");
                }
            }
        });

        foodDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=foodName.getText().toString();
                String kcl=foodKcal.getText().toString();
                String calDate = year.getText().toString()+month.getText().toString()+day.getText().toString();

                int nameSize = name.length();
                int kclSize = kcl.length();
                if(nameSize <= 0 || kclSize <= 0){
                    Toast.makeText(getApplicationContext(),"음식명 혹은 칼로리를 입력하세요", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    sqlDB = foodHelper.getWritableDatabase();
                    sqlDB.execSQL("DELETE FROM foodTBL WHERE fName = \"" + name + "\"AND fKcal =\"" + Integer.parseInt(kcl) + "\";");
                    sqlDB.close();

                    sqlDB = foodHelper.getReadableDatabase();
                    Cursor cursor;
                    cursor = sqlDB.rawQuery("SELECT fName, fKcal FROM foodTBL WHERE Date=\"" + calDate + "\"", null);
                    String strNames = "음식 이름" + "\r\n" + "-------" + "\r\n";
                    String strKcal = "칼 로 리" + "\r\n" + "-------" + "\r\n";

                    int totalCal = 0;
                    while (cursor.moveToNext()) {
                        strNames += cursor.getString(0) + "\r\n";
                        strKcal += Integer.toString(cursor.getInt(1)) + "\r\n";
                        totalCal = totalCal + cursor.getInt(1);
                    }
                    foodNameResult.setText(strNames);
                    foodKcalResult.setText(strKcal);
                    foodTotalCal.setText(Integer.toString(totalCal));
                    cursor.close();
                    sqlDB.close();
                    foodName.setText("");
                    foodKcal.setText("");
                }
            }
        });
        foodSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}