package com.cookandroid.myproject;


import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

import static java.lang.Integer.parseInt;

/**
 * Created by J on 2016-11-03.
 */
public class drink extends Activity {
    LinearLayout linear, linear2;
    CalendarView calendar;
    ImageView alramBtn, backBtn, listBtn;
    TextView text_water50, text_water100, text_water500, total_water, calText;
    Button addBtn_water50, subBtn_water50, addBtn_water100, subBtn_water100,
            addBtn_water500, subBtn_water500, save_water, cancel_water, selectBtn;
    Integer num50 = 0, num100 = 0, num500 = 0, total_num = 0;
    Integer Year = 0, Month = 0, Date = 0;
    View dialogView;
    int hour = 0;
    int minute = 0;
    AlarmManager manager;
    TimePicker timePicker;
    myDBhelper waterHelper;
    SQLiteDatabase sqlDB;
    Integer beforeTotal=0;
    Integer before50 = 0, before100 = 0, before500 = 0;

    //알람 대화상자에서 해제 누를 시 사용되는 함수
    private PendingIntent pendingIntent3() {
        Toast.makeText(getApplicationContext(), "종료", Toast.LENGTH_LONG).show();
        Intent intent1 = new Intent(getApplicationContext(), musicService.class);
        PendingIntent pi = PendingIntent.getService(getApplicationContext(), 0, intent1, 0);
        stopService(intent1);
        manager.cancel(pi);
        return pi;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drink);

        alramBtn = (ImageView) findViewById(R.id.alramBtn);
        text_water50 = (TextView) findViewById(R.id.text_water50);
        text_water100 = (TextView) findViewById(R.id.text_water100);
        text_water500 = (TextView) findViewById(R.id.text_water500);
        total_water = (TextView) findViewById(R.id.total_water);
        addBtn_water50 = (Button) findViewById(R.id.addBtn_water50);
        subBtn_water50 = (Button) findViewById(R.id.subBtn_water50);
        addBtn_water100 = (Button) findViewById(R.id.addBtn_water100);
        subBtn_water100 = (Button) findViewById(R.id.subBtn_water100);
        addBtn_water500 = (Button) findViewById(R.id.addBtn_water500);
        subBtn_water500 = (Button) findViewById(R.id.subBtn_water500);
        save_water = (Button) findViewById(R.id.save_water);
        cancel_water = (Button) findViewById(R.id.cancel_water);
        backBtn = (ImageView) findViewById(R.id.backBtn);
        listBtn = (ImageView) findViewById(R.id.listBtn);
        calText = (TextView) findViewById(R.id.calText);
        linear = (LinearLayout) findViewById(R.id.linear);
        linear2 = (LinearLayout) findViewById(R.id.linear2);
        calendar = (CalendarView) findViewById(R.id.calendar);
        selectBtn = (Button) findViewById(R.id.selectBtn);

        waterHelper = new myDBhelper(this);

        final Calendar curDate = Calendar.getInstance();

        Year = curDate.get(Calendar.YEAR);
        Month = 1 + curDate.get(Calendar.MONTH);
        Date = curDate.get(Calendar.DATE);
        calText.setText(Year.toString() + "." + Month.toString() + "." + Date.toString());

        boolean SearchDate = false;
        String date = Year.toString() + "." + Month.toString() + "." + Date.toString();

        //데이터베이스에 들어있는 값 가져오기
        sqlDB = waterHelper.getReadableDatabase();
        Cursor cursor;
        cursor = sqlDB.rawQuery("SELECT * FROM waterTBL", null);

        while (cursor.moveToNext()) {
            String strDate = cursor.getString(0);
            before50 = cursor.getInt(1);
            before100 = cursor.getInt(2);
            before500 = cursor.getInt(3);
            beforeTotal = cursor.getInt(4);

            if (strDate.equals(date)) {
                SearchDate = true;
                break;
            } else {
                SearchDate = false;
            }
        }
        cursor.close();
        sqlDB.close();

        //이전 값 가져오기
        if (SearchDate == true) {
            text_water50.setText(Html.fromHtml("<u>" + before50.toString() + "</u>"));
            text_water100.setText(Html.fromHtml("<u>" + before100.toString() + "</u>"));
            text_water500.setText(Html.fromHtml("<u>" + before500.toString() + "</u>"));
            total_water.setText(Html.fromHtml("<u>" + beforeTotal.toString() + "</u>"));

            num50 += before50;
            num100 += before100;
            num500 += before500;
            total_num += beforeTotal;
        } else {
            text_water50.setText(Html.fromHtml("<u>" + num50.toString() + "</u>"));
            text_water100.setText(Html.fromHtml("<u>" + num100.toString() + "</u>"));
            text_water500.setText(Html.fromHtml("<u>" + num500.toString() + "</u>"));
            total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
        }

        calText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linear.setVisibility(View.INVISIBLE);
                linear2.setVisibility(View.VISIBLE);
                calendar.setVisibility(View.VISIBLE);
                selectBtn.setVisibility(View.VISIBLE);
            }
        });

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                num50 = 0;
                num100 = 0;
                num500 = 0;
                total_num = 0;
                Year = year;
                Month = 1 + month;
                Date = dayOfMonth;
                calText.setText(Year.toString() + "." + Month.toString() + "." + Date.toString());

                boolean SearchDate = false;
                String date = Year.toString() + "." + Month.toString() + "." + Date.toString();

                sqlDB = waterHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT * FROM waterTBL", null);

                while (cursor.moveToNext()) {
                    String strDate = cursor.getString(0);
                    before50 = cursor.getInt(1);
                    before100 = cursor.getInt(2);
                    before500 = cursor.getInt(3);
                    beforeTotal = cursor.getInt(4);

                    if (strDate.equals(date)) {
                        SearchDate = true;
                        break;
                    } else {
                        SearchDate = false;
                    }
                }
                cursor.close();
                sqlDB.close();


                if (SearchDate == true) {
                    text_water50.setText(Html.fromHtml("<u>" + before50.toString() + "</u>"));
                    text_water100.setText(Html.fromHtml("<u>" + before100.toString() + "</u>"));
                    text_water500.setText(Html.fromHtml("<u>" + before500.toString() + "</u>"));
                    total_water.setText(Html.fromHtml("<u>" + beforeTotal.toString() + "</u>"));

                    num50 += before50;
                    num100 += before100;
                    num500 += before500;
                    total_num += beforeTotal;
                } else {
                    text_water50.setText(Html.fromHtml("<u>" + num50.toString() + "</u>"));
                    text_water100.setText(Html.fromHtml("<u>" + num100.toString() + "</u>"));
                    text_water500.setText(Html.fromHtml("<u>" + num500.toString() + "</u>"));
                    total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
                }
            }
        });

        selectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linear2.setVisibility(View.INVISIBLE);
                linear.setVisibility(View.VISIBLE);
            }
        });

        //알람 아이콘 클릭 시 동작하는 리스너
        alramBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogView = (View) View.inflate(drink.this, R.layout.alram_setting, null);
                manager = (AlarmManager) getSystemService(ALARM_SERVICE);
                AlertDialog.Builder dlg = new AlertDialog.Builder(drink.this);
                dlg.setTitle("알람 설정");
                dlg.setView(dialogView);


                dlg.setPositiveButton("설정", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        timePicker = (TimePicker) dialogView.findViewById(R.id.timePicker);

                        final Intent intent = new Intent(getApplicationContext(), musicService.class);
                        final PendingIntent pi = PendingIntent.getService(getApplicationContext(), 0, intent, 0);

                        hour = timePicker.getCurrentHour();
                        minute = timePicker.getCurrentMinute();

                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, hour);
                        calendar.set(Calendar.MINUTE, minute);
                        calendar.set(Calendar.SECOND, 0);
                        //1시간마다 알람 반복
                        manager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), 1000*60*60, pi);
                        Toast.makeText(getApplicationContext(), hour + "시" + minute + "분에 알람을 설정하였습니다.", Toast.LENGTH_LONG).show();
                    }
                });

                dlg.setNegativeButton("해제", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "알람이 해제되었습니다.", Toast.LENGTH_SHORT).show();
                        pendingIntent3();
                    }
                });

                dlg.show();
            }
        });

        addBtn_water50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num50 += 50;
                text_water50.setText(Html.fromHtml("<u>" + num50 + "</u>"));
                total_num += 50;
                total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
            }
        });
        addBtn_water100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num100 += 100;
                text_water100.setText(Html.fromHtml("<u>" + num100 + "</u>"));
                total_num += 100;
                total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
            }
        });
        addBtn_water500.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                num500 += 500;
                text_water500.setText(Html.fromHtml("<u>" + num500 + "</u>"));
                total_num += 500;
                total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
            }
        });
        subBtn_water50.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (num50 > 0) {
                    num50 -= 50;
                    text_water50.setText(Html.fromHtml("<u>" + num50.toString() + "</u>"));
                    total_num -= 50;
                    total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
                } else {
                    return;
                }

            }
        });
        subBtn_water100.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (num100 > 0) {
                    num100 -= 100;
                    text_water100.setText(Html.fromHtml("<u>" + num100.toString() + "</u>"));
                    total_num -= 100;
                    total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
                } else {
                    return;
                }
            }
        });
        subBtn_water500.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (num500 > 0) {
                    num500 -= 500;
                    text_water500.setText(Html.fromHtml("<u>" + num500.toString() + "</u>"));
                    total_num -= 500;
                    total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));
                } else {
                    return;
                }
            }
        });
        //저장 버튼
        save_water.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean SearchDate = false;
                String date = Year.toString() + "." + Month.toString() + "." + Date.toString();

                Integer sumWater = parseInt(text_water50.getText().toString()) +
                        parseInt(text_water100.getText().toString()) +
                        parseInt(text_water500.getText().toString());


                sqlDB = waterHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT Date FROM waterTBL", null);

                while (cursor.moveToNext()) {
                    String strDate = cursor.getString(0);
                    if (strDate.equals(date)) {
                        SearchDate = true;
                        break;
                    } else {
                        SearchDate = false;
                    }
                }
                cursor.close();
                sqlDB.close();

                if (SearchDate == true) {
                    sqlDB = waterHelper.getWritableDatabase();
                    sqlDB.execSQL("UPDATE waterTBL SET Water50 = " + text_water50.getText().toString() + ", Water100 = " +
                            text_water100.getText().toString() + ", Water500 = " + text_water500.getText().toString() + ", WaterTotal = "
                            + sumWater + " WHERE Date = '" + date + "';");
                    sqlDB.close();
                    Toast.makeText(getApplicationContext(), "수정되었습니다.", Toast.LENGTH_SHORT).show();
                } else {
                    sqlDB = waterHelper.getWritableDatabase();
                    sqlDB.execSQL("INSERT INTO waterTBL VALUES('" + date + "',"
                            + text_water50.getText().toString() + ","
                            + text_water100.getText().toString() + ","
                            + text_water500.getText().toString() + "," + sumWater + ");");
                    sqlDB.close();
                    Toast.makeText(getApplicationContext(), "입력되었습니다.", Toast.LENGTH_SHORT).show();

                }
            }

        });
        //초기화 버튼
        cancel_water.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = Year.toString() + "." + Month.toString() + "." + Date.toString();

                sqlDB = waterHelper.getWritableDatabase();
                sqlDB.execSQL("DELETE FROM waterTBL WHERE Date = '" + date + "';");
                sqlDB.close();

                num50 = 0;
                num100 = 0;
                num500 = 0;
                total_num = 0;

                text_water50.setText(Html.fromHtml("<u>" + num50.toString() + "</u>"));
                text_water100.setText(Html.fromHtml("<u>" + num100.toString() + "</u>"));
                text_water500.setText(Html.fromHtml("<u>" + num500.toString() + "</u>"));
                total_water.setText(Html.fromHtml("<u>" + total_num.toString() + "</u>"));

                Toast.makeText(getApplicationContext(), "삭제되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });
        //왼쪽 위 아이콘 눌렀을 때 메인으로
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //통계 리스트뷰 waterList.class 액티비티로 값 넘겨주기
        listBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqlDB = waterHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT * FROM waterTBL ORDER BY Date ASC;", null);
                int i = 0;

                String strDate[] = new String[cursor.getCount()];
                int water50[] = new int[cursor.getCount()];
                int water100[] = new int[cursor.getCount()];
                int water500[] = new int[cursor.getCount()];
                int waterTotal[] = new int[cursor.getCount()];

                Intent intent = new Intent(getApplicationContext(), waterList.class);

                while (cursor.moveToNext()) {
                    strDate[i] = cursor.getString(0);
                    water50[i] = cursor.getInt(1);
                    water100[i] = cursor.getInt(2);
                    water500[i] = cursor.getInt(3);
                    waterTotal[i] = cursor.getInt(4);
                    i++;
                }
                cursor.close();
                sqlDB.close();

                intent.putExtra("strDate", strDate);
                intent.putExtra("water50", water50);
                intent.putExtra("water100", water100);
                intent.putExtra("water500", water500);
                intent.putExtra("waterTotal", waterTotal);

                startActivity(intent);
            }
        });
    }
}