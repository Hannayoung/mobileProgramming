package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

/**
 * Created by nayoung on 2016-11-03.
 */

public class SecondActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.loading);

        Intent intent = getIntent();
        Handler handler = new Handler();
        handler.postDelayed(new SecondActivity.splashHandler(), 3000);

    }

    class splashHandler implements Runnable {
        public void run() {
            finish();
        }
    }
}

