package com.cookandroid.myproject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class waterList extends Activity {
    ListViewAdapter adapter;
    ListView waterList;
    String list[];
    Integer water_total[];
    Integer water_50[];
    Integer water_100[];
    Integer water_500[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.waterlist);
        waterList = (ListView) findViewById(R.id.waterList);

        //drink액티비티에서 보낸 값 가져오기
        Intent intent = getIntent();
        final String strDate[] = intent.getStringArrayExtra("strDate");
        final int water50[] = intent.getIntArrayExtra("water50");
        int water100[] = intent.getIntArrayExtra("water100");
        int water500[] = intent.getIntArrayExtra("water500");
        int waterTotal[] = intent.getIntArrayExtra("waterTotal");

        list = new String[strDate.length];
        water_total = new Integer[strDate.length];
        water_50 = new Integer[strDate.length];
        water_100 = new Integer[strDate.length];
        water_500 = new Integer[strDate.length];

        adapter = new ListViewAdapter();
        waterList.setAdapter(adapter);

        for (int i = 0; i < strDate.length; i++) {
            water_total[i] = waterTotal[i];
            water_50[i] = water50[i];
            water_100[i] = water100[i];
            water_500[i] = water500[i];
            adapter.addItem(ContextCompat.getDrawable(this, R.drawable.drops),
                    strDate[i], "Total : " + water_total[i].toString());
        }
        adapter.notifyDataSetChanged();

        //리스트뷰 항목 클릭 시 대화상자 출력
        waterList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Integer sWater = water_50[position] / 50;
                Integer mWater = water_100[position] / 100;
                Integer lWater = water_500[position] / 500;
                AlertDialog.Builder dlg = new AlertDialog.Builder(waterList.this);
                dlg.setTitle(strDate[position]);
                dlg.setMessage("50ml : 50 * " + sWater.toString() + "\r\n"
                        + "100ml : 100 * " + mWater.toString() + "\r\n"
                        + "500ml : 500 * " + lWater.toString() + "\r\n"
                        + "합계 : " + water_total[position].toString() + "ml" + "\r\n");
                dlg.setPositiveButton("닫기", null);
                dlg.show();
            }
        });
    }
}