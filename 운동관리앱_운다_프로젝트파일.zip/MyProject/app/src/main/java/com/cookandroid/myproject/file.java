package com.cookandroid.myproject;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class file extends Activity {
    Button btnReturn;
    ListView fileList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.file);

        btnReturn = (Button)findViewById(R.id.btnReturn);
        fileList = (ListView)findViewById(R.id.fileList);

        String fileDir = "/data/data/com.cookandroid.myproject/files";
        File[] files = (new File(fileDir)).listFiles();
        int fileSize = files.length;

        final String[] strFname = new String[fileSize];
        for (int i=0; i < files.length; i++) {
            strFname[i] = files[i].getName();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, strFname);
        fileList.setAdapter(adapter);

        fileList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                try {
                    InputStream inFs = openFileInput(strFname[i]);
                    byte[] txt = new byte[30];
                    inFs.read(txt);
                    inFs.close();
                    String strTxt = (new String(txt)).trim();

                    AlertDialog.Builder dlg = new AlertDialog.Builder(file.this);
                    dlg.setTitle(strFname[i]);
                    dlg.setMessage(strTxt);
                    dlg.setPositiveButton("확인", null);
                    dlg.show();
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(), "저장된 파일이 없습니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });
    }
}