package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class email extends Activity implements AdapterView.OnItemSelectedListener {
    EditText titleEdit, phoneEdit, contentEdit;
    Button positive;
    String[] str={"이메일", "폰 번호"};
    String content = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.email);

        titleEdit = (EditText) findViewById(R.id.titleEdit);
        phoneEdit = (EditText) findViewById(R.id.phoneEdit);
        contentEdit = (EditText) findViewById(R.id.contentEdit);
        positive  = (Button) findViewById(R.id.positive);
        Spinner spin = (Spinner) findViewById(R.id.spinner);
        //스피너에 아이템을 클릭 했을때 실행될 리스너(액티비티)
        spin.setOnItemSelectedListener(email.this);

        /*
         * 어댑터 배열 객체 생성(this는 Context 메인 액티비티를 가리킴,
         * 안드로이드에 있는 어댑터 객체 에서 지원해주는 스피너 레이아웃,아이템 배열)
         * android는 안드로이드가 가지고 있는 전역 변수
         */
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                email.this, android.R.layout.simple_spinner_item, str);

        //adapter를 통해 리스트 형태로 늘리는 메소드
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // 어댑터 설정
        spin.setAdapter(adapter);

        positive.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                content ="연락처 : "+ phoneEdit.getText().toString() + " 내용 : "+ contentEdit.getText().toString();
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("message/rfc822");
                i.putExtra(Intent.EXTRA_EMAIL  , new String[]{"hny4813@naver.com"});
                i.putExtra(Intent.EXTRA_SUBJECT, titleEdit.getText().toString());
                i.putExtra(Intent.EXTRA_TEXT   , content);
                try {
                    startActivity(Intent.createChooser(i, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(email.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {}

    public void onNothingSelected(AdapterView<?> parent) {}
}
