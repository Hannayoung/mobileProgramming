package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Administrator on 2016-05-31.
 */
public class password extends Activity {
    EditText Pw1, Pw2, Pw3, Pw4;
    TextView Tv1, Tv2, Tv3, Tv4;
    String text = "";
    SQLiteDatabase sqlDB;


    public boolean CheckPassword(String pass) {
        final passMyDBHelper myDBHelper = new passMyDBHelper(password.this);
        sqlDB = myDBHelper.getReadableDatabase();
        Cursor cursor = sqlDB.rawQuery("SELECT * FROM customer;", null);


        if (cursor.getCount()==1)
            return true;

        else
            return false;

    }

    public void Init_EditText() {

        Tv1.setVisibility(View.INVISIBLE);
        Tv2.setVisibility(View.INVISIBLE);
        Tv3.setVisibility(View.INVISIBLE);
        Tv4.setVisibility(View.INVISIBLE);

        Pw1.setVisibility(View.VISIBLE);
        Pw2.setVisibility(View.VISIBLE);
        Pw3.setVisibility(View.VISIBLE);
        Pw4.setVisibility(View.VISIBLE);

        Pw1.requestFocus();
        Pw1.setCursorVisible(true);
        text = "";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.password);
        Intent intent = getIntent();

        // *모양 TextView
        Tv1 = (TextView) findViewById(R.id.tv1);
        Tv2 = (TextView) findViewById(R.id.tv2);
        Tv3 = (TextView) findViewById(R.id.tv3);
        Tv4 = (TextView) findViewById(R.id.tv4);
        //TextView 감추기
        Tv1.setVisibility(View.INVISIBLE);
        Tv2.setVisibility(View.INVISIBLE);
        Tv3.setVisibility(View.INVISIBLE);
        Tv4.setVisibility(View.INVISIBLE);
        //비밀번호를 한 글자씩 입력받는 EditText
        Pw1 = (EditText) findViewById(R.id.pw1);
        Pw2 = (EditText) findViewById(R.id.pw2);
        Pw3 = (EditText) findViewById(R.id.pw3);
        Pw4 = (EditText) findViewById(R.id.pw4);




//여기까지



        Pw1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override //EditText에 변화가 있을 때
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (Pw1.length() == 1) {
                    text += Pw1.getText();
                    //table row의 텍스트 값을 가져옴.

                    Pw1.removeTextChangedListener(this);
                    Pw1.setText("");
                    Pw1.addTextChangedListener(this);

                    Pw1.clearFocus();

                    Pw2.requestFocus();

                }
            }

            @Override  //입력 후
            public void afterTextChanged(Editable s) {
                Pw1.setVisibility(View.INVISIBLE);
                Tv1.setVisibility(View.VISIBLE);
            }

        });

        Pw2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (Pw2.length() == 1) {
                    text += Pw2.getText();
                    Pw2.removeTextChangedListener(this);
                    Pw2.setText("");
                    Pw2.addTextChangedListener(this);
                    Pw2.clearFocus();

                    Pw3.requestFocus();
                    Pw3.setCursorVisible(true);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                Pw2.setVisibility(View.INVISIBLE);
                Tv2.setVisibility(View.VISIBLE);
            }
        });

        Pw3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (Pw3.length() == 1) {
                    text += Pw3.getText();
                    Pw3.removeTextChangedListener(this);
                    Pw3.setText("");
                    Pw3.addTextChangedListener(this);
                    Pw3.clearFocus();

                    Pw4.requestFocus();
                    Pw4.setCursorVisible(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                Pw3.setVisibility(View.INVISIBLE);
                Tv3.setVisibility(View.VISIBLE);
            }
        });

        Pw4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (Pw4.length() == 1) {
                    text += Pw4.getText().toString();
                    Pw4.removeTextChangedListener(this);
                    Pw4.setText("");
                    Pw4.addTextChangedListener(this);

                    boolean PasswordTrue;

                    PasswordTrue = CheckPassword(text);

                    if (PasswordTrue == true) {
                        Init_EditText();
                        finish();
                    } else {
                        Toast.makeText(getApplicationContext(), "비밀번호가 틀렸습니다.", Toast.LENGTH_SHORT).show();
                        Init_EditText();
                    }
                }
            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }
}
