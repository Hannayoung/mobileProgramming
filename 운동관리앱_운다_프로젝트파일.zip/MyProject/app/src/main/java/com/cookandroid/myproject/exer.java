package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class exer extends Activity {
    Button exBtn1, exBtn2, exBtn3, exBtn4, exBtn5, exBtn6, exBtn7, exBtn8, exBtn9, sendBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exer);

        Intent intent = getIntent();
        exBtn1 = (Button) findViewById(R.id.exBtn1);
        exBtn2 = (Button) findViewById(R.id.exBtn2);
        exBtn3 = (Button) findViewById(R.id.exBtn3);
        exBtn4 = (Button) findViewById(R.id.exBtn4);
        exBtn5 = (Button) findViewById(R.id.exBtn5);
        exBtn6 = (Button) findViewById(R.id.exBtn6);
        exBtn7 = (Button) findViewById(R.id.exBtn7);
        exBtn8 = (Button) findViewById(R.id.exBtn8);
        exBtn9 = (Button) findViewById(R.id.exBtn9);
        sendBtn = (Button) findViewById(R.id.sendBtn);


        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent5 = new Intent(getApplicationContext(), email.class);
                startActivity(intent5);

            }
        });

        exBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/885806"));
                startActivity(mIntent);
            }
        });

        exBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/790455"));
                startActivity(mIntent);
            }
        });

        exBtn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/812931"));
                startActivity(mIntent);
            }
        });

        exBtn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/864320"));
                startActivity(mIntent);
            }
        });


        exBtn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/823181"));
                startActivity(mIntent);
            }
        });

        exBtn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/875132"));
                startActivity(mIntent);
            }
        });

        exBtn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/504671"));
                startActivity(mIntent);
            }
        });

        exBtn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/875143"));
                startActivity(mIntent);
            }
        });

        exBtn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://tvcast.naver.com/v/832211"));
                startActivity(mIntent);
            }
        });

    }
}