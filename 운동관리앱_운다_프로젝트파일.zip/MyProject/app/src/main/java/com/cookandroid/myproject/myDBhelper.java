package com.cookandroid.myproject;

/**
 * Created by LG on 2016-11-11.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class myDBhelper extends SQLiteOpenHelper {
    public myDBhelper(Context context){
        super(context,"groupDB", null,1);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE waterTBL (Date String PRIMARY KEY, Water50 INTEGER, Water100 INTEGER, Water500 INTEGER, WaterTotal INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS waterTBL");
        onCreate(db);
    }
}