package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class setting extends Activity {
    SQLiteDatabase sqlDB;
    EditText editSet1, editSet3, editSet4;
    Button btnSet, btnConf;
    TextView NameResult, HeightResult, WeightResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);
        Intent intent = getIntent();
        editSet1 = (EditText) findViewById(R.id.editSet1); //이름
        editSet3 = (EditText) findViewById(R.id.editSet3); //키
        editSet4 = (EditText) findViewById(R.id.editSet4); //몸무게
        btnSet  = (Button)findViewById(R.id.btnSet); //입력하기 버튼
        btnConf = (Button) findViewById(R.id.btnConf); //정보확인 버튼
        NameResult = (TextView) findViewById(R.id.NameResult); //이름조회
        HeightResult = (TextView) findViewById(R.id.HeightResult); //키조회
        WeightResult = (TextView) findViewById(R.id.WeightResult); //몸무게조회

        final cusMyDBHelper myHelper = new cusMyDBHelper(setting.this);


        btnSet.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                sqlDB.execSQL("INSERT INTO customer2 VALUES ( '" + editSet1.getText().toString() + "', " + Integer.parseInt(editSet3.getText().toString()) + ", " + Integer.parseInt(editSet4.getText().toString()) + " );");
                sqlDB.close();
                Toast.makeText(getApplicationContext(), "입력됨",
                        Toast.LENGTH_SHORT).show();
            }
        });

        btnConf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), inquire.class);
                startActivity(intent);
            }
        });

   }

}