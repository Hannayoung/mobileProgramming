package com.cookandroid.myproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class cusMyDBHelper extends SQLiteOpenHelper {
    public cusMyDBHelper(Context context) {
        super(context, "customer2", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE customer2 (name text, height INTEGER, weight INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS customer2");
        onCreate(db);
    }
}
