package com.cookandroid.myproject;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 김승은 on 2016-11-13.
 */
public class inquire extends Activity {
    TextView NameResult, HeightResult, WeightResult;
    SQLiteDatabase sqlDB;
    Button inquire, reset, home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inquire);
        Intent intent = getIntent();
        final cusMyDBHelper myHelper = new cusMyDBHelper(inquire.this);

        NameResult = (TextView) findViewById(R.id.NameResult); //이름조회
        HeightResult = (TextView) findViewById(R.id.HeightResult); //키조회
        WeightResult = (TextView) findViewById(R.id.WeightResult); //몸무게조회
        inquire = (Button) findViewById(R.id.inquire);  //조회버튼
        reset = (Button) findViewById(R.id.reset);  //초기화버튼
        home = (Button) findViewById(R.id.home);    //홈으로버튼

        inquire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sqlDB = myHelper.getReadableDatabase();
                Cursor cursor;
                cursor = sqlDB.rawQuery("SELECT * FROM customer2;", null);

                String strName = "<이름>" + "\r\n";
                String strHeight = "<키>" +  "\r\n";
                String strWeight = "<몸무게>" +  "\r\n";

                while (cursor.moveToNext()) {
                    strName += cursor.getString(0) + "\n";
                    strHeight += cursor.getString(1) + "cm" + "\n";
                    strWeight += cursor.getString(2) + "kg" + "\n";
                }

                NameResult.setText(strName);
                HeightResult.setText(strHeight);
                WeightResult.setText(strWeight);
                cursor.close();
                sqlDB.close();
            }
        });


        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sqlDB = myHelper.getWritableDatabase();
                myHelper.onUpgrade(sqlDB, 0,1); // 인수는 아무거나 입력하면 됨.
                sqlDB.close();
                Toast.makeText(getApplicationContext(), "초기화 됨",
                        Toast.LENGTH_SHORT).show();
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }
}