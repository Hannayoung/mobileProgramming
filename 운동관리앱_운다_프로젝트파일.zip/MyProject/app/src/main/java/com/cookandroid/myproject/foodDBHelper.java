package com.cookandroid.myproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class foodDBHelper extends SQLiteOpenHelper {
    public foodDBHelper(Context context) {
        super(context, "foodTBL", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE foodTBL (Date TEXT, fName CHAR(15), fKcal INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST foodTBL");
        onCreate(db);
    }
}