package com.cookandroid.myproject;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class WidgetProvider extends AppWidgetProvider {

    @Override
	public void onReceive(Context context, Intent intent) {
		super.onReceive(context, intent);
	}

	public static void updateAppWidget(Context context,
                                       AppWidgetManager appWidgetManager, int appWidgetId) {
        Calendar mCalendar = Calendar.getInstance();
        SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm",
                Locale.KOREA);
        RemoteViews updateViews = new RemoteViews(context.getPackageName(),
                R.layout.widget_layout);

        updateViews.setTextViewText(R.id.mText,
                mFormat.format(mCalendar.getTime()));
        appWidgetManager.updateAppWidget(appWidgetId, updateViews);
    }//위젯 갱신 시 실행

    @Override
    public void onEnabled(Context context) {
		super.onEnabled(context);
	}//위젯 초기 생성 시 실행
	@Override
	public void onDisabled(Context context) {
		super.onDisabled(context);
	}//위젯 마지막 인스턴스 제거될 때 실행
	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		super.onDeleted(context, appWidgetIds);
	}//사용자가 위젯 삭제할 때 실행
	@Override
	public void onAppWidgetOptionsChanged(Context context,
			AppWidgetManager appWidgetManager, int appWidgetId,
			Bundle newOptions) {
	//	super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId,newOptions);


		int minWidth = newOptions
				.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH);
		int maxWidth = newOptions
				.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH);
		int minHeight = newOptions
				.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT);
		int maxHeight = newOptions
				.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT);

		RemoteViews updateViews = null;

		if (maxWidth >= 432) {
			updateViews = new RemoteViews(context.getPackageName(),
					R.layout.widget_layout4x);
		} else {
			updateViews = new RemoteViews(context.getPackageName(),
					R.layout.widget_layout);
		}   //가로 길이에 따른 글자 크기 설정

    Intent intent = new Intent(context,MainActivity.class);
    PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
    updateViews.setOnClickPendingIntent(R.id.mLayout, pendingIntent);
    //위젯 클릭하면 메인액티비티 실행되도록

   // updateViews.setTextViewText(R.id.cm,);

    Calendar mCalendar = Calendar.getInstance();
    SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm",
    Locale.KOREA);
    updateViews.setTextViewText(R.id.mText,mFormat.format(mCalendar.getTime()));
    appWidgetManager.updateAppWidget(appWidgetId, updateViews);
    //시간가져오기
	}



}