package com.cookandroid.myproject;

/**
 * Created by LG on 2016-11-15.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.util.AbstractCollection;

/**
 * Created by Heemin on 2016-11-15.
 */
public class notification extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent outIntent = new Intent(getApplicationContext(), drink.class);
        startActivity(outIntent);
    }
}