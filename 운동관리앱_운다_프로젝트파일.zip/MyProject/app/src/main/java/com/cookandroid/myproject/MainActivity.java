package com.cookandroid.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ListView;


public class MainActivity extends ActionBarActivity {
    ImageButton homeBtn;
    Button runBtn, foodBtn, drinkBtn, exerBtn, btnSet;
    DrawerLayout dl_activity_main_drawer;
    ListView lv_activity_main_nav_list;
    FrameLayout fl_activity_main_container;
    private String[] navItems = {"HOME", "RUNNING", "FOOD",
            "DRINKING", "EXERCISING", "SETTING", "EMAIL"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent7 = new Intent(getApplicationContext(), prePassword.class);
        startActivity(intent7);
        Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
        startActivity(intent);


        homeBtn = (ImageButton)findViewById(R.id.homeBtn);
        runBtn = (Button)findViewById(R.id.runBtn);
        foodBtn = (Button)findViewById(R.id.foodBtn);
        drinkBtn = (Button)findViewById(R.id.drinkBtn);
        exerBtn = (Button)findViewById(R.id.exerBtn);
        btnSet = (Button)findViewById(R.id.btnSet);
        dl_activity_main_drawer = (DrawerLayout)findViewById(R.id.dl_activity_main_drawer);
        lv_activity_main_nav_list = (ListView)findViewById(R.id.lv_activity_main_nav_list);
        fl_activity_main_container = (FrameLayout)findViewById(R.id.fl_activity_main_container);

        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(getApplicationContext(), setting.class);
                startActivity(intent3);
            }
        });

        lv_activity_main_nav_list.setAdapter( new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, navItems));
        lv_activity_main_nav_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 1:
                        Intent intent1 = new Intent(getApplicationContext(), run.class);
                        startActivity(intent1);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 2:
                        Intent intent2 = new Intent(getApplicationContext(), food.class);
                        startActivity(intent2);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 3:
                        Intent intent3 = new Intent(getApplicationContext(), drink.class);
                        startActivity(intent3);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 4:
                        Intent intent4 = new Intent(getApplicationContext(), exer.class);
                        startActivity(intent4);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 5:
                        Intent intent5 = new Intent(getApplicationContext(), setting.class);
                        startActivity(intent5);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                    case 6:
                        Intent intent6 = new Intent(getApplicationContext(), email.class);
                        startActivity(intent6);
                        dl_activity_main_drawer.closeDrawer(lv_activity_main_nav_list);
                        break;
                }
            }
        });

        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dl_activity_main_drawer.openDrawer(lv_activity_main_nav_list);
            }
        });

        runBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(getApplicationContext(),run.class);
                startActivity(intent1);
            }
        });

        foodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(getApplicationContext(),food.class);
                startActivity(intent2);
            }
        });

        drinkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3 = new Intent(getApplicationContext(),drink.class);
                startActivity(intent3);
            }
        });

        exerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent4 = new Intent(getApplicationContext(),exer.class);
                startActivity(intent4);
            }
        });
    }
}
