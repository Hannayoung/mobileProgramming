package com.cookandroid.myproject;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by J on 2016-11-10.
 */

public class musicService extends Service {
    NotificationManager mNotificationManager;
    MediaPlayer mp;
    @Nullable

    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        android.util.Log.i("서비스테스트", "onCreate()");
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        android.util.Log.i("서비스 테스트", "onDestroy()");
        mp.stop();
        mNotificationManager.cancel(1);
        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        android.util.Log.i("서비스 테스트", "onStartCommand()");

        Intent intent1 = new Intent(musicService.this, notification.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this,0,intent1,PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.drop)
                .setContentTitle("물 마실 시간")
                .setContentText("클릭해주세요!")
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);
        mNotificationManager =(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(1, mBuilder.build());

        mp = MediaPlayer.create(this, R.raw.bgm);
        mp.start();
        //20초만 나오고 노래 끄기
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            public void run() {
                mp.stop();
                musicService.super.onDestroy();
            }
        }, 20000);

        return super.onStartCommand(intent, flags, startId);
    }
}

