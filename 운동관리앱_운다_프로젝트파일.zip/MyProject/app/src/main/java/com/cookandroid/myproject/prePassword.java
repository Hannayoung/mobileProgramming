package com.cookandroid.myproject;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

/**
 * Created by nayoung on 2016-11-10.
 */

public class prePassword extends Activity {
    RadioGroup group;
    RadioButton loginBtn, joinBtn;
    EditText pwEdit;
    Button confBtn, saveBtn;
    TextView pwText;
    SQLiteDatabase sqlDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prepassword);
        Intent intent = getIntent();
        group = (RadioGroup) findViewById(R.id.group);
        loginBtn = (RadioButton)findViewById(R.id.loginBtn);
        joinBtn = (RadioButton)findViewById(R.id.joinBtn);
        pwEdit = (EditText)findViewById(R.id.pwEdit);
        confBtn = (Button)findViewById(R.id.confBtn);
        saveBtn = (Button)findViewById(R.id.saveBtn);
        pwText = (TextView)findViewById(R.id.pwText);

        confBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switch(group.getCheckedRadioButtonId())
                {
                    case R.id.loginBtn:
                        Intent intent1 = new Intent(getApplicationContext(), password.class);
                        startActivity(intent1);
                        finish();
                        break;
                    case R.id.joinBtn:
                        pwText.setVisibility(android.view.View.VISIBLE);
                        pwEdit.setVisibility(android.view.View.VISIBLE);
                        saveBtn.setVisibility(android.view.View.VISIBLE);
                        break;
                }
            }
        });

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final passMyDBHelper myDBHelper = new passMyDBHelper(prePassword.this);
                sqlDB = myDBHelper.getWritableDatabase();
                sqlDB.execSQL("DROP TABLE IF EXISTS customer");
                sqlDB.execSQL("CREATE TABLE customer (password TEXT);");
                sqlDB.execSQL("INSERT INTO customer VALUES('"+pwEdit.getText().toString()+"');");
                sqlDB.close();

                // sqlDB = myDBHelper.getReadableDatabase();
                //  Cursor cursor = sqlDB.rawQuery("SELECT password FROM customer "+"where password=\""+pwEdit+"\"", null);

                //pwText.setText(cursor.getString(0));
                //cursor.close();
                Intent intent2 = new Intent(getApplicationContext(), password.class);
                startActivity(intent2);
                sqlDB.close();
                finish();
            }
        });
    }
}
